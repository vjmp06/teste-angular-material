import {Component, OnInit} from '@angular/core';
import { NgForm} from '@angular/forms';

export interface Numero {
  id: number;
  extenso: string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  states = [
    { name: "Name 1" , id: "1", photo: "test1"},
    { name: "Name 2" , id: "2", photo: "test2"},
    { name: "Name 3" , id: "3", photo: "test3"},
  ]; 
  
  onSubmit(form: NgForm) {
    console.log(form)
  }

  recebeId($event) {
    console.log("Ta aqui os dados oh!");
    console.log($event);
  }
}
